# Önceki bağımsız incelemenin yeniden kullanımı

REPORT.md, COMPLETION.json ve root-adoption.json önceki V225 incelemesinden değişmeden alınmıştır. İnceleme eski özel denemenin aynı piksel dosyalarına aittir; bu paket için yeni bağımsız inceleme yapılmadı. Bu paketteki açık natural-v5 çekimleri aynı önce/sonra PNG özetlerine sahiptir. Sonraki gerçek çekim kabulü audits/native-audit.public.json içindedir.

Önceki rapordaki “henüz benimsenmedi” gibi durumlar o incelemenin tarihsel sınırıdır. Eski MANIFEST yerel kullanıcı yolları içerdiğinden özgün hali yayımlanmaz; MANIFEST.public.json açıkça ayıklanmış türevdir. Görsel kazanç her iki aile için yararlı bulunmuştu; büyük uçtaki kaba/çapraz doku ve daha gerçekçi inci/metal ihtiyacı sürüyor. Bu değerlendirme fiziksel taş, stok, hareketli optik veya V03 son kalite kabulü değildir.
