# V225 independent actual-pixel review

**NO-FIX for the bounded incremental visual-gain checkpoint. Visible useful gain: bracelet YES; necklace YES.** The candidate gives tiger-eye a much more legible fibrous identity in both ordinary whole-jewelry views. It is worth retaining as an incremental candidate. This is an independent visual recommendation, not atlas adoption, native/GPU acceptance, or V03 product acceptance; those remain Root's decisions.

## Evidence and comparison boundary

Opened all four original PNGs directly with `view_image`, after verifying their actual byte lengths, SHA-256 hashes and 1710 x 842 PNG dimensions. No crops, resizes, enhancements, new renders or code-derived appearance assumptions were used. Opened the original V03 A/B concept images separately as visual references only.

| Actual capture | Bytes | SHA-256 |
| --- | ---: | --- |
| initial-bracelet.png | 1285716 | 0a37d0e75188a782daabfc07ac1734b6c11c37dd3fcbc6832a931d47c518aac9 |
| candidate-bracelet.png | 1321889 | bda4d2c4dc2800f46c060bdaf83680553a17926f7111952ff48417f36b2dca5b |
| initial-necklace.png | 1208596 | f25c63ed922babad5668a9f498a42902932f3682ac65e2fed0069c5393a54722 |
| candidate-necklace.png | 1233091 | 973ba27b50a314785ee6de310a260f92a54249543d6e3453e8b22862aa587da5 |

The paired companion JSONs have identical Recipe hashes before/after and across variants: bracelet `b6252389b5ded5654413dbe7a3b6299ca3eacf44c4500688c5f6a7aa2cd61a20`; necklace `c3d269c3522acb7457b6626cc1cd1a9f9bacf09f71e14604d0865ff17847ef1f`. All 30 supplied `crossContextComparable` fields compare equal per family, including ordinary camera, geometry, source image, viewport, lighting/rig, floor/support, shadow and quality. The requests differ only in `tigerAtlasStudyRequested`; both use terrace/high/auto/perspective and an 855 x 421 CSS frame. The JSON declares exact original36/72 fixtures and natural-v4 appearances, with only the tiger pigment study selection changing. These are checks of the supplied capture records, not independent runtime attestation. Both records explicitly retain `runtimeSourceVerified=false`; Root owns served-source, driver, native data and return-control proof.

Verified the actual V221 and V223R1 manifest files against the assigned hashes. Local source identity is declared as `cbc052598acf56c756f819f6cf72bafd5b5248b8`; no Git tree, remote or runtime source claim is added by this review. `MANIFEST.json` pins every inspected input and the review outputs.

## Pixel observations

Coordinates below are approximate pixel locations in the original 1710 x 842 captures, measured from the upper-left.

| Family / location | Initial to candidate observation | Judgment |
| --- | --- | --- |
| Bracelet front tiger bead, x765-945 / y558-741 | The initial has broad smooth brown/gold sweeps with little fine structure. The candidate has many readable golden fibres, darker streaks and irregular grain across the visible sphere. This is obvious at the ordinary framing; no enlarged detail view is needed. | Useful gain YES. Less generic polished-plastic appearance, stronger tiger-eye identity. |
| Bracelet upper-left tiger bead, x290-425 / y232-348; upper-right, x1285-1420 / y232-348 | Both acquire visible fibrous detail instead of largely smooth amber. The upper-left contains a conspicuous coarse dark patch near x325-383 / y249-297; the upper-right has dense dark/gold bands below its two bright reflections. | Gain is present on more than the hero bead. Coarse wood-grain/painted texture remains a risk. |
| Bracelet front bead transitions, around x817-908 / y585-702 | Bright amber fibre regions meet a darker central/right patch with strong irregular streak contrast. The surface is richer but occasionally reads scratched or wood-like rather than a smooth stone with depth. The original broad curved striping is replaced by a much busier field. | Residual realism issue, not a reason to discard the useful incremental gain. No unmistakable hard rectangular atlas seam is visible at this view. |
| Necklace pendant, x800-912 / y628-769 | The initial reads as a broad dark brown slab with soft diagonal striping. The candidate has much finer golden fibres, a darker middle and a clearly changed surface. The detail is visible in the full composition. | Useful gain YES. The dominant pendant is more materially specific. |
| Necklace pendant fibre direction, x811-900 / y650-739 | Fine strokes intersect or change direction through the center and lower part. This dense crosshatching gives a brush/scratched-wood or woven appearance. It is less convincingly polished gemstone than the best V03 tiger-eye reference. | Strongest remaining candidate weakness. Static pixels do not establish an optical chatoyancy effect. |
| Necklace tiger beads, front-left x497-572 / y476-548, front-right x1137-1212 / y476-548, and rear pair near x774/y99 and x936/y99 | All receive visible gold/brown grain; the change is not confined to the pendant. At whole-necklace distance the finer structure contributes more than individual strand shapes. | Useful gain across the family. The many small beads are too small here to rule out texture tiling or repeated motifs. |

**Repetition:** no obvious identical stamped motif dominates these two whole-jewelry frames. The three bracelet tiger beads share a similar dark/gold fibrous formula, but this view does not prove per-bead uniqueness or seam-free mapping. The necklace's small beads provide still less evidence for either claim.

**Plastic / painted / baked lighting:** the candidate reduces the initial tiger beads' smooth plastic look, while the pendant and coarse patches can still read like surface-applied wood grain. The white specular highlights remain in corresponding locations and preserve the bead silhouettes. These are fixed-light still pairs; they cannot prove whether the apparent fibre brightness is baked, nor whether a moving band follows view/light correctly. No dynamic-lighting claim is made.

## Whole-jewelry composition and V03 distance

The bracelet remains a centered, continuous oval with the clasp at the rear and a clear front tiger-eye focal point. The necklace remains a continuous oval with a readable pendant below the center. Matching silhouettes, bead positions, background and highlight locations support a localized material change; no obvious composition or silhouette regression is visible. The candidate's increased texture contrast draws the eye more strongly to the tiger stones, particularly the pendant, without obscuring the arrangement.

There is still a substantial gap to V03 A/B. In the concept close-ups, tiger-eye has calmer directional bands, a glossy sense of depth and controlled luminous transitions. The actual candidate is comparatively noisy, especially on the pendant. Across the whole actual jewelry, pearls remain comparatively plain white spheres, grey beads have a granular/mottled reading, highlights repeat strongly, and the contact/reflection treatment is less physically convincing than the concepts. The pendant's broad face and the sparse separator rhythm also give a different composition from the concept jewelry. Those observations identify the remaining visual distance; they are not failures introduced by this pigment-only change or instructions to retune geometry/lighting in this checkpoint. The supplied actuals contain the render only, so they do not establish V03 UI, mobile usability or editor behavior.

## Smallest next proposal, limits and rollback

No mandatory fix is requested for this incremental checkpoint. If Root continues toward the V03 tiger-eye finish, the smallest next material target is the pendant's crossing/coarse fibre field: make its directional structure more coherent while preserving the useful fine-grain identity. Do not open a hue, camera, lighting, geometry or size-tuning campaign on the strength of this review. View-dependent optical/baked-light questions need a separately authorized matching motion observation; these stills cannot answer them.

Only the assigned V225 output folder was created/written. No product/source/public/mirror/browser/account/provider changes, installs, new renders, children, tests or builds were made. No external services were called; native included tools only; incremental spend USD 0. Atlas remains unadopted. Review rollback is deletion of this output folder by its owner; all input images, manifests and source state remain untouched. Lease CLOSED after delivery of the complete report, completion contract and file-pin manifest.
