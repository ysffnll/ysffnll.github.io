# JEW Studio · gerçek 3D görüntü dosyaları · 01 Kasım 2026

native/ içinde altı özgün, değiştirilmemiş PNG vardır: bileklik ve kolye için önce / yeni taş dokusu / önceki sürüme dönüş. Dönüş görüntüleri ilk görüntülerle byte düzeyinde aynıdır. 1710×842 görüntüler kırpılmadı, yeniden boyutlandırılmadı veya düzenlenmedi.

Teknik .public-proof.json ve audits/*.public.json dosyaları açık alan listesiyle ayıklanmış türevlerdir; özgün tam JSON olarak sunulmazlar. Yerel çalışma yolları, yerel tarayıcı adresleri, hesap/sağlayıcı ve kullanıcı depolama bağlamı seçilmedi. Her türev özgün kaydın byte/SHA256 kimliğini taşır. Geometri/kamera/malzeme kaydının seçili kanıt alanları korunur.

recipes/ iki yeni natural-v5 örneğinin H2 uygulamasından alınmış özgün kanonik dosyalarını ve iki eski natural-v4 sabit örneğini içerir. Yeni örnekler aynı tasarımlardır; eski P01 kullanılır. Uygun sürümlü atölyede dosya açarak düzenlenebilirler.

material-samples/ içindeki on PNG, beş kaynak için özgün temiz 3D detay ve küçük örnektir. Sabit malzeme örnekleridir; birebir seçilen taş deseni veya gerçek stok değildir. Birleşik P01J kaynak örneği yalnız uyumluluk kanıtıdır; galeride veya başlangıç tasarımlarında yeni bir seçenek olarak etkinleştirilmez.

independent-review/ önceki V225 incelemesini açık tarihsel sınırlarıyla yeniden kullanır; yeni bir bağımsız inceleme yapılmadı. Kullanılan dört gerçek pikselin aynı olduğu SHA256 ile doğrulandı. Yararlı doku kazancı, final fotoğraf gerçekçiliği veya V03 kabulü anlamına gelmez. Büyük uç dokusu, inci ve metal üzerinde iş sürüyor.

MANIFEST.json üyelerin byte/SHA256 kimliklerini verir; kendisini özyinelemeli olarak hashlemez. PNG ve örnek tasarımlar özgündür; kamuya hazırlanan JSON ve açıklayıcı notlar açıkça etiketlidir. Bu paket yeni canlı site, fiziksel üretim, cihaz, insan kullanılabilirliği veya yeni GPU testi sonucu değildir.
